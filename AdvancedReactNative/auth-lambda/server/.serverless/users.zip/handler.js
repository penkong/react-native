module.exports = {
  userWithPhoneExists: require('./src/user_with_phone_exists'),
  userCreate: require('./src/user_create'),
  sendOneTimePass: require('./src/send_one_time_pass'),
  verifyOneTimePass: require('./src/verify_one_time_pass')
};
